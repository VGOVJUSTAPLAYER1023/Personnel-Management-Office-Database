// Military RP Dashboard - Frontend
// Works in Demo Mode (localStorage) or with Cloudflare D1 via /api/*

const API_BASE = '/api'; // Cloudflare Pages Functions
const DEMO_MODE = true;  // Set false when D1 is connected

// ---------- Rank list (matches schema) ----------
const RANKS = [
  { name: 'Recruit', level: 1, points_required: 0, color: '#6b7280' },
  { name: 'Private', level: 2, points_required: 50, color: '#4b5563' },
  { name: 'Private First Class', level: 3, points_required: 120, color: '#374151' },
  { name: 'Corporal', level: 4, points_required: 250, color: '#1f2937' },
  { name: 'Sergeant', level: 5, points_required: 400, color: '#065f46' },
  { name: 'Staff Sergeant', level: 6, points_required: 600, color: '#047857' },
  { name: 'Sergeant First Class', level: 7, points_required: 900, color: '#059669' },
  { name: 'Master Sergeant', level: 8, points_required: 1300, color: '#10b981' },
  { name: 'First Sergeant', level: 9, points_required: 1800, color: '#34d399' },
  { name: 'Sergeant Major', level: 10, points_required: 2500, color: '#6ee7b7' },
  { name: 'Lieutenant', level: 11, points_required: 3200, color: '#3b82f6' },
  { name: 'Captain', level: 12, points_required: 4500, color: '#2563eb' },
  { name: 'Major', level: 13, points_required: 6000, color: '#1d4ed8' },
  { name: 'Colonel', level: 14, points_required: 8000, color: '#1e40af' },
  { name: 'General', level: 15, points_required: 12000, color: '#f59e0b' },
];

// ---------- Demo data store ----------
let members = [];
let activity = [];

function loadDemoData() {
  const saved = localStorage.getItem('milrp_members');
  if (saved) {
    members = JSON.parse(saved);
  } else {
    members = [
      {
        id: 1,
        roblox_username: 'ExampleSoldier1',
        roblox_id: '123456789',
        discord_username: 'SoldierOne#0001',
        discord_id: '111111111111111111',
        rank: 'Sergeant',
        points: 450,
        status: 'Active',
        division: 'Infantry',
        notes: 'Reliable NCO',
        join_date: '2025-01-15',
        last_seen: new Date().toISOString()
      },
      {
        id: 2,
        roblox_username: 'ExamplePilot',
        roblox_id: '987654321',
        discord_username: 'AcePilot#0420',
        discord_id: '222222222222222222',
        rank: 'Lieutenant',
        points: 3400,
        status: 'Active',
        division: 'Aviation',
        notes: '',
        join_date: '2024-11-02',
        last_seen: new Date().toISOString()
      },
      {
        id: 3,
        roblox_username: 'NewRecruit99',
        roblox_id: '555555555',
        discord_username: 'FreshMeat#9999',
        discord_id: '333333333333333333',
        rank: 'Recruit',
        points: 10,
        status: 'Active',
        division: 'Infantry',
        notes: 'Just joined',
        join_date: '2026-09-20',
        last_seen: new Date().toISOString()
      },
      {
        id: 4,
        roblox_username: 'TankCommander',
        roblox_id: '444444444',
        discord_username: 'ArmorKing',
        discord_id: '444444444444444444',
        rank: 'Staff Sergeant',
        points: 720,
        status: 'On Leave',
        division: 'Armor',
        notes: 'Leave until Oct 30',
        join_date: '2025-03-10',
        last_seen: '2026-09-01T12:00:00Z'
      }
    ];
    saveDemoData();
  }

  const savedAct = localStorage.getItem('milrp_activity');
  activity = savedAct ? JSON.parse(savedAct) : [
    { id: 1, member: 'ExampleSoldier1', action: 'Promoted to Sergeant', points_change: 0, by: 'System', created_at: '2026-08-12T10:00:00Z' },
    { id: 2, member: 'ExamplePilot', action: 'Points awarded for event', points_change: 150, by: 'Commander', created_at: '2026-09-05T18:30:00Z' }
  ];
}

function saveDemoData() {
  localStorage.setItem('milrp_members', JSON.stringify(members));
  localStorage.setItem('milrp_activity', JSON.stringify(activity));
}

// ---------- API helpers (ready for real backend) ----------
async function apiGet(path) {
  if (DEMO_MODE) return null;
  const res = await fetch(API_BASE + path);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

async function apiPost(path, body) {
  if (DEMO_MODE) return null;
  const res = await fetch(API_BASE + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

// ---------- UI Helpers ----------
function statusBadge(status) {
  const map = {
    'Active': 'badge-active',
    'Inactive': 'badge-inactive',
    'On Leave': 'badge-leave',
    'Banned': 'badge-banned'
  };
  return `<span class="badge ${map[status] || 'badge-inactive'}">${status}</span>`;
}

function rankBadge(rank) {
  const r = RANKS.find(x => x.name === rank);
  const color = r ? r.color : '#6b7280';
  return `<span class="rank-badge" style="color:${color};border:1px solid ${color}33">${rank}</span>`;
}

function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString();
}

// ---------- Render functions ----------
function renderStats() {
  const total = members.length;
  const active = members.filter(m => m.status === 'Active').length;
  const inactive = members.filter(m => m.status !== 'Active').length;
  const points = members.reduce((s, m) => s + (m.points || 0), 0);

  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-active').textContent = active;
  document.getElementById('stat-inactive').textContent = inactive;
  document.getElementById('stat-points').textContent = points.toLocaleString();
}

function renderRecentTable() {
  const tbody = document.querySelector('#recent-table tbody');
  const recent = [...members].sort((a, b) => new Date(b.join_date) - new Date(a.join_date)).slice(0, 5);
  tbody.innerHTML = recent.map(m => `
    <tr>
      <td><strong>${escapeHtml(m.roblox_username)}</strong></td>
      <td>${escapeHtml(m.discord_username || '—')}</td>
      <td>${rankBadge(m.rank)}</td>
      <td>${m.points}</td>
      <td>${statusBadge(m.status)}</td>
    </tr>
  `).join('');
}

function renderMembersTable(filter = {}) {
  const tbody = document.querySelector('#members-table tbody');
  let list = [...members];

  if (filter.status) list = list.filter(m => m.status === filter.status);
  if (filter.division) list = list.filter(m => m.division === filter.division);
  if (filter.rank) list = list.filter(m => m.rank === filter.rank);
  if (filter.search) {
    const q = filter.search.toLowerCase();
    list = list.filter(m =>
      (m.roblox_username || '').toLowerCase().includes(q) ||
      (m.discord_username || '').toLowerCase().includes(q) ||
      (m.roblox_id || '').includes(q) ||
      (m.discord_id || '').includes(q)
    );
  }

  tbody.innerHTML = list.map(m => `
    <tr>
      <td>${m.id}</td>
      <td><strong>${escapeHtml(m.roblox_username)}</strong><br><small style="color:#6b7280">${m.roblox_id || ''}</small></td>
      <td>${escapeHtml(m.discord_username || '—')}<br><small style="color:#6b7280">${m.discord_id || ''}</small></td>
      <td>${rankBadge(m.rank)}</td>
      <td><strong>${m.points}</strong></td>
      <td>${escapeHtml(m.division)}</td>
      <td>${statusBadge(m.status)}</td>
      <td>
        <button class="btn btn-ghost btn-sm" onclick="editMember(${m.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteMember(${m.id})">Del</button>
      </td>
    </tr>
  `).join('') || '<tr><td colspan="8" style="text-align:center;color:#6b7280">No members found</td></tr>';
}

function renderRanks() {
  const grid = document.getElementById('ranks-grid');
  grid.innerHTML = RANKS.map(r => `
    <div class="rank-card" style="border-left-color:${r.color}">
      <h4 style="color:${r.color}">${r.name}</h4>
      <div class="level">Level ${r.level}</div>
      <div class="req">${r.points_required.toLocaleString()} pts required</div>
    </div>
  `).join('');
}

function renderActivity() {
  const tbody = document.querySelector('#activity-table tbody');
  const list = [...activity].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  tbody.innerHTML = list.map(a => `
    <tr>
      <td>${formatDate(a.created_at)}</td>
      <td>${escapeHtml(a.member)}</td>
      <td>${escapeHtml(a.action)}</td>
      <td style="color:${a.points_change > 0 ? '#34d399' : a.points_change < 0 ? '#f87171' : 'inherit'}">
        ${a.points_change > 0 ? '+' : ''}${a.points_change}
      </td>
      <td>${escapeHtml(a.by)}</td>
    </tr>
  `).join('') || '<tr><td colspan="5" style="text-align:center;color:#6b7280">No activity yet</td></tr>';
}

function populateRankSelects() {
  const selects = [document.getElementById('rank'), document.getElementById('filter-rank')];
  selects.forEach(sel => {
    if (!sel) return;
    const current = sel.value;
    sel.innerHTML = (sel.id === 'filter-rank' ? '<option value="">All Ranks</option>' : '') +
      RANKS.map(r => `<option value="${r.name}">${r.name}</option>`).join('');
    if (current) sel.value = current;
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ---------- CRUD ----------
function openModal(editId = null) {
  const modal = document.getElementById('member-modal');
  const form = document.getElementById('member-form');
  form.reset();
  document.getElementById('member-id').value = '';
  document.getElementById('modal-title').textContent = editId ? 'Edit Member' : 'Add Member';

  if (editId) {
    const m = members.find(x => x.id === editId);
    if (m) {
      document.getElementById('member-id').value = m.id;
      document.getElementById('roblox_username').value = m.roblox_username || '';
      document.getElementById('roblox_id').value = m.roblox_id || '';
      document.getElementById('discord_username').value = m.discord_username || '';
      document.getElementById('discord_id').value = m.discord_id || '';
      document.getElementById('rank').value = m.rank || 'Recruit';
      document.getElementById('points').value = m.points || 0;
      document.getElementById('division').value = m.division || 'Infantry';
      document.getElementById('status').value = m.status || 'Active';
      document.getElementById('notes').value = m.notes || '';
    }
  }
  modal.classList.remove('hidden');
}

function closeModal() {
  document.getElementById('member-modal').classList.add('hidden');
}

function editMember(id) {
  openModal(id);
}

function deleteMember(id) {
  if (!confirm('Delete this member permanently?')) return;
  const m = members.find(x => x.id === id);
  members = members.filter(x => x.id !== id);
  if (m) {
    activity.unshift({
      id: Date.now(),
      member: m.roblox_username,
      action: 'Member deleted',
      points_change: 0,
      by: 'Commander',
      created_at: new Date().toISOString()
    });
  }
  saveDemoData();
  refreshAll();
}

document.getElementById('member-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const id = document.getElementById('member-id').value;
  const data = {
    roblox_username: document.getElementById('roblox_username').value.trim(),
    roblox_id: document.getElementById('roblox_id').value.trim(),
    discord_username: document.getElementById('discord_username').value.trim(),
    discord_id: document.getElementById('discord_id').value.trim(),
    rank: document.getElementById('rank').value,
    points: parseInt(document.getElementById('points').value, 10) || 0,
    division: document.getElementById('division').value,
    status: document.getElementById('status').value,
    notes: document.getElementById('notes').value.trim()
  };

  if (id) {
    const idx = members.findIndex(x => x.id === parseInt(id, 10));
    if (idx !== -1) {
      const old = members[idx];
      members[idx] = { ...old, ...data, updated_at: new Date().toISOString() };
      activity.unshift({
        id: Date.now(),
        member: data.roblox_username,
        action: 'Member updated',
        points_change: data.points - (old.points || 0),
        by: 'Commander',
        created_at: new Date().toISOString()
      });
    }
  } else {
    const newId = members.length ? Math.max(...members.map(m => m.id)) + 1 : 1;
    members.push({
      id: newId,
      ...data,
      join_date: new Date().toISOString().slice(0, 10),
      last_seen: new Date().toISOString(),
      created_at: new Date().toISOString()
    });
    activity.unshift({
      id: Date.now(),
      member: data.roblox_username,
      action: 'Member added',
      points_change: 0,
      by: 'Commander',
      created_at: new Date().toISOString()
    });
  }

  saveDemoData();
  closeModal();
  refreshAll();
});

// ---------- Navigation & Filters ----------
function switchView(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('view-' + view).classList.add('active');
  document.querySelector(`.nav-btn[data-view="${view}"]`).classList.add('active');

  const titles = {
    dashboard: 'Dashboard',
    members: 'Members Roster',
    ranks: 'Rank Structure',
    activity: 'Activity Log',
    settings: 'Settings & Deployment'
  };
  document.getElementById('page-title').textContent = titles[view] || view;
}

function getFilters() {
  return {
    status: document.getElementById('filter-status').value,
    division: document.getElementById('filter-division').value,
    rank: document.getElementById('filter-rank').value,
    search: document.getElementById('global-search').value.trim()
  };
}

function refreshAll() {
  renderStats();
  renderRecentTable();
  renderMembersTable(getFilters());
  renderRanks();
  renderActivity();
}

// ---------- Event listeners ----------
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});

document.getElementById('btn-add-member').addEventListener('click', () => openModal());
document.getElementById('modal-close').addEventListener('click', closeModal);
document.getElementById('modal-cancel').addEventListener('click', closeModal);
document.getElementById('btn-refresh').addEventListener('click', () => {
  loadDemoData();
  refreshAll();
});

['filter-status', 'filter-division', 'filter-rank'].forEach(id => {
  document.getElementById(id).addEventListener('change', () => renderMembersTable(getFilters()));
});

document.getElementById('global-search').addEventListener('input', () => {
  renderMembersTable(getFilters());
});

// Close modal on outside click
document.getElementById('member-modal').addEventListener('click', (e) => {
  if (e.target.id === 'member-modal') closeModal();
});

// ---------- Init ----------
loadDemoData();
populateRankSelects();
refreshAll();
console.log('%c Military RP Dashboard ready (Demo Mode) ', 'background:#10b981;color:#000;padding:4px 8px;border-radius:4px');
