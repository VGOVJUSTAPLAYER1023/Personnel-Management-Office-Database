// Cloudflare Pages Function example
// Path: /api/members
// Requires D1 binding named "DB"

export async function onRequestGet(context) {
  const { env } = context;
  if (!env.DB) {
    return new Response(JSON.stringify({ error: "D1 not bound", demo: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  }

  try {
    const { results } = await env.DB.prepare(
      "SELECT * FROM members ORDER BY points DESC"
    ).all();
    return Response.json(results);
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}

export async function onRequestPost(context) {
  const { env, request } = context;
  if (!env.DB) {
    return new Response(JSON.stringify({ error: "D1 not bound" }), { status: 500 });
  }

  const body = await request.json();
  const {
    roblox_username, roblox_id, discord_username, discord_id,
    rank, points, status, division, notes
  } = body;

  try {
    const result = await env.DB.prepare(`
      INSERT INTO members (roblox_username, roblox_id, discord_username, discord_id, rank, points, status, division, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      roblox_username, roblox_id || null, discord_username || null, discord_id || null,
      rank || 'Recruit', points || 0, status || 'Active', division || 'Infantry', notes || null
    ).run();

    return Response.json({ success: true, id: result.meta.last_row_id });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
